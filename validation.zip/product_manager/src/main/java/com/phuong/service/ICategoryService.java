package com.phuong.service;

import com.phuong.model.Category;

import java.util.List;

public interface ICategoryService {
    List<Category> findAll();
}
